package oramag.marapr.thirteen.adf.error.utils.sample.controller;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import oracle.adf.controller.ControllerContext;

import oracle.jbo.JboException;


/**
 * ADFc Exception Handler managed bean that is called from a method activity defined as the error activity. The
 * exception is simply shown in a dialog for a coonsistent look and feel of errors.
 *
 * Another popular approach for handling ADFc errors is to use a router activity referencing a managed bean method
 * to return true or false for a specific error type. Code similar to the one in this class would be used to parse
 * the error message for the problem source (usually an error code). Navigation cases decalarative defined in the
 * router would the access different methods to check where to route the request to.
 *
 * @author Frank Nimphius
 */
public class AdfcSampleErrorHandlerImpl {
    public AdfcSampleErrorHandlerImpl() {
        super();
    }

    /**
     * Method that shows the controller exception in a dialog. Note that a dialog is one way to handle
     * exceptions. 
     */
    public void showAdfcErrorMessageInDialog() {
        String ORAMAG_PREFIX = "Oracle Magazine Error Handler : \n"; 
        
        ControllerContext cc = ControllerContext.getInstance();

        Exception ex = cc.getCurrentViewPort().getExceptionData();
        JboException jboException = null;

        if (ex instanceof JboException) {
            jboException = (JboException)ex;
        } else {
            jboException = new JboException(ex);
        }

        //TODO: You can implement localized messages by reading the error message
        //from a resource bundle for a specific error code. 
        String errorMessage =  ORAMAG_PREFIX+jboException.getMessage();

        //display error message a faces dialog
        FacesContext fc = FacesContext.getCurrentInstance();        
        FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR, errorMessage, null);
        fc.addMessage(null, facesMessage);

        cc.getCurrentRootViewPort().clearException();
        fc.renderResponse();
    }
}
