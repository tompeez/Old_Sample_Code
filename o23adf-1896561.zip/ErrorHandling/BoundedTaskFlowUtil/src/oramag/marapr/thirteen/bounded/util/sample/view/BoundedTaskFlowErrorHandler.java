package oramag.marapr.thirteen.bounded.util.sample.view;

import oramag.marapr.thirteen.adf.error.utils.sample.controller.AdfcSampleErrorHandlerImpl;

public class BoundedTaskFlowErrorHandler extends AdfcSampleErrorHandlerImpl {
    public BoundedTaskFlowErrorHandler() {
        super();
    }

}
