package oramag.marapr.thirteen.unbounded.util.sample.view;

import oramag.marapr.thirteen.adf.error.utils.sample.controller.AdfcSampleErrorHandlerImpl;

public class UnboundedTaskFlowErrorHandler extends AdfcSampleErrorHandlerImpl {
    public UnboundedTaskFlowErrorHandler() {
        super();
    }
}
