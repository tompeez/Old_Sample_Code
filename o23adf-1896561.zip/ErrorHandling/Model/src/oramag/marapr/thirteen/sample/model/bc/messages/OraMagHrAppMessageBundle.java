package oramag.marapr.thirteen.sample.model.bc.messages;

import java.util.ListResourceBundle;

/**
 * Message Bundle to override default ADF BC error messages
 * @author Frank Nimphius
 */
public class OraMagHrAppMessageBundle extends ListResourceBundle {
    private static final Object[][] sMessageStrings = new String[][] {{ /*fill in 2-D array here*/}};

    /**Return String Identifiers and corresponding Messages in a two-dimensional array.
     */
    protected Object[][] getContents() {
        return sMessageStrings;
    }
}
