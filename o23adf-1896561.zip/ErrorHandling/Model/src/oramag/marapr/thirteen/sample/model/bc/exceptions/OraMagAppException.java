package oramag.marapr.thirteen.sample.model.bc.exceptions;

import oracle.jbo.JboException;
import oracle.jbo.common.ResourceBundleDef;

public class OraMagAppException extends JboException {
    @SuppressWarnings("compatibility:7262249838603631786")
    private static final long serialVersionUID = -6900713936036645755L;

    public OraMagAppException(Class class1, String string, Object[] objects, Exception[] exceptions) {
        super(class1, string, objects, exceptions);
    }

    public OraMagAppException(Class class1, String string, Object[] objects, JboException[] jboExceptions) {
        super(class1, string, objects, jboExceptions);
    }

    public OraMagAppException(ResourceBundleDef resourceBundleDef, String string, Object[] objects) {
        super(resourceBundleDef, string, objects);
    }

    public OraMagAppException(Class class1, String string, Object[] objects) {
        super(class1, string, objects);
    }

    public OraMagAppException(Throwable throwable) {
        super(throwable);
    }

    public OraMagAppException(String string) {
        super(string);
    }

    public OraMagAppException(String string, String string1, Object[] objects) {
        super(string, string1, objects);
    }
}
